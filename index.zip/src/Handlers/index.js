module.exports = {
    EventHandler: require('./events'),
    ComamnadHandler: require('./commands'),
}